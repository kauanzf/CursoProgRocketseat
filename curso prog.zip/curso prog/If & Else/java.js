let temperatura = 36.5

if (temperatura>= 37){
    console.log("esta com febre")
}{
    console.log("n esta com febre")
}

switch(expression){
    case 'a':
        //code
    case 'b':
        //code
    
    case 'default':
    console.log("ahhhhh")
    break
  
}

//trow

function sayMyName(name = ''){
    if (name == ""){
        throw new Error("Preencha o bloco nome")
    }
}

try{
    sayMyName
}catch(e){
        console.log(e)
}

//for

for(let i = 0; i < 10; i++){
    // while "I" keeps below the value "10" the loop will keep going until it become 10 or higher

if(i == 5) {
    break;
        //"IF" is used to make a limit or a condition IF a limit reaches, "BREAK" end the loop and "CONTINUE" ignore a number
}
}

//while
let = 231242342

while(i > 10){
    console.log(i)

    i/=35
}

// //for of

// let name = "Kauan"
// let names = ["Carlos", "Pedro", "Miguel"]

// for(let char of names){
//         console.log(char)
// }

//for in 
let person = {
    name: 'John',
    age: 30,
    weight: 88.6
}

for (let property in person){
    console.log(property)
    console.log(person.name)
    console.log(person[property])
}