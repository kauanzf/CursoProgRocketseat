const sum = function (number1, number2){

}
sum (2,3)


//Function scope
let subject = "create a video"

function createThink(subject){
    subject = "study"
    return subject
}

console.log(createThink(subject))
console.log(subject)

//arrow function 

const sayMyName = () =>{
    console.log("kauan")

    //strings in numbers
    // let string = "123"
    // console.log(Number(string))
    // let number = 321
    // console.log(String(number))

    //change the "." to a ","
    let number = 345.43243
    console.log(number.toFixed(2).replace("." , ","))

    //change a word to upper case or lower case

    let word = "frase"
    console.log(word.toUpperCase())
    let word1 = "FRASE"
    console.log(word1.toLowerCase())

    // removes a chosed content from the string

    let phrase = "i want to live the love!"
    let myArray = phrase.split("o") //the "split" remove the content
    console.log(myArray)

    //controlling arrays

    let techs = ["html", "css", "js"]
    //adding a item to the end
    techs.push("nodejs")
    //adding a item to the end
    techs.unshift("sql")
   
    //removing from the end
   
    // techs.pop
   
    //removing from the start
   
    // techs.shift
    
    //choosing specifics elements in the array 
    
    // console.log(techs.slice(1, 3))
    
    // removing 1 or more items in any position at the array 
    // techs.splice(1, 2)

    //finding a position of an element at the array 
    let index = techs.indexOf("css")
    console.log(index)

    //expressions and operators 

    //new 

    let name = new String("kauan")
    name.surName = "Zanella"
    let age = new Number(17)
    console.log(name.surName, age)

    //typeof delete
    const person = {
        name: 'kauan',
        age: 17,
    }
    delete person.age
    
    console.log(person)
} 