

// console.log(12.5 * 6)

// console.log(12/2)

// console.log(34 + 67)

// console.log(34 - 96)

let remainder

remainder = 11 % 3
console.log(remainder)

let increment = 0
increment++
console.log(increment)

let decrement = 0
console.log(decrement--)
console.log(--decrement)



let pao = true
let queijo = false

//AND &&

console.log(pao && queijo)

//OR ||

console.log(pao || queijo)

//NOT !
console.log(!pao)

let pao1 = true
let queijo1 = true

const niceBreakfast = pao1 && queijo1 ? 'cafe top' : 'cafe ruim'

console.log(niceBreakfast)

//+18

let age = 18

const canDrive = age >= 18 ? 'can drive' : 'cannot drive'

